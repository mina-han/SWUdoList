from django.apps import AppConfig


class SwudolistConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'swudolist'
